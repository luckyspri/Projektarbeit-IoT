# -0- Hinweis
'''
Dies ist die Hauptdatei welche aufgerufen werden muss.
Die folgenden Anweisungen sind für Linux, unter Windows gibt es kleine Unterschiede, siehe hierzu die offizielle FLASK-
Um mit dieser Datei einen Server starten zu können, muss in der Komandozeile FLASK informiert werden, dass dies die FLASK-App ist
dafür muss in der Komandozeile in diesen Ordner navigiert werden. (schaue hierfür die nötigen Komandos nach, entscheidend sind  cd  und  ls
im Ordner angekommen, durch die Eingabe "export FLASK_APP=run.py" das dies die Datei ist, die von FLASK gestartet werden soll.
Der Server wird über "flask run" gestartet.
Um Veränderungen im Code auf der Website zu sehen, muss der Server, in der Komandozeile, mit Ctlr + C gestopt und neugestartet werden.
wird mit export FLASK_DEBUG=1 der Debug-Mode aktiviert ersparte man sich das neustarten des Servers. eine Aktualisierung des Browsers ist nun ausreichend.
Der nun erscheinende Link kann im Browser geöffnet werden 
'''


#-1- alle Module werden importiert
from flask import Flask, render_template #Flask Module
from actors_sensors import Light, Rollo, LightSensor #Module, welche die Klassen für alle Aktoren und Sensoren bereitstellen
from apps import Index, SmartHome #als Module externalisierte Apps
import threading


# -2- Grundeinstellungen für die volle Funktionsfähigkeit der Website

app = Flask(__name__) #Flask-standard Belegung (Konvetion)


#alle Links der Nav-bar müssen hier aufgehührt werden ("name","interner Link")
all_apps=[("Startseite","/"),
	("Smart Home","/smarthome")]

# -3- für alle Aktoren und Sensoren werden hier die entsprechenden Objekte erstellt und diese sortiert
 
#alle LED-Objekte werden erstellt
light_1 = Light("light_1",3)
#light_2 = Light("light_2",2)
#light_3 = Light("light_3",1)
#light_4 = Light("light_4",0)

#in der folgenden Liste wird gespeichert, welches Licht an und welches Licht aus ist
#dies ist entscheidend für die Steuerung durch den MCP23017
light_configuration_list= [0,0,0,0]


#für die bessere Handhabung werden die LED-Objekte hier gruppiert
all_lights = [light_1] #,light_2,light_3,light_4]

#alle Rolladenobjekte werden hier erstellt
rollo_1 = Rollo("rollo_1",18,23,24,25)
#rollo_2 = Rollo("rollo_2",12,16,20,21)
#rollo_3 = Rollo("rollo_3",26,19,13,5)
#rollo_4 = Rollo("rollo_4",4,17,27, 22)


#für die bessere Handhabung werden die Rolladen-Objekte hier gruppiert
all_rollos = [rollo_1] #,rollo_2,rollo_3, rollo_4]

#standardmäßig soll jeder Rollo oben sein, es wird bei der Objet Erstellung deffiniert, dass self.status="up"

#um zu bestimmen ob der Rollo oben ist, werden die Daten von Lichtsensoren abgefragt.
#hierfür hat jeder Rollo ein Lichtsensor. diese geben ein go raus, solange bis eine schwarze Linie erreicht wird.

sensor_1 = LightSensor("sensor_1", 7)
#sensor_2 = LightSensor("sensor_2", 6)
#sensor_3 = LightSensor("sensor_3", 5)
#sensor_4 = LightSensor("sensor_4", 4)

#für die bessere Handhabung werden die Sensor-Objekte hier gruppiert
all_sensors = [sensor_1] #, sensor_2, sensor_3, sensor_4]

#den Rollos werden die enstprechenden Sensoren zugeordnet

rollos_sensors = {
    rollo_1 : sensor_1,
    #rollo_2 : sensor_2,
    #rollo_3 : sensor_3,
    #rollo_4 : sensor_4
    }

#nun werden alle Rollos in die "up" position gefahren       

for i in range (len(all_rollos)):
    rollo = all_rollos[i]
    sensor = rollos_sensors[rollo]
    thread =threading.Thread(target=rollo.go_to_startposition, name="rollo.name", args=(sensor,))
    thread.start()

#Zimmer werden in Liste zusammengefassst

all_rooms=["Zimmer 1","Zimmer 2","Zimmer 3","Zimmer 4"]

#jedem Zimmer werden in einem Dictionary einzelne Aktoren (und Sensoren) zugeordnet

zuordnung_dic={
    all_rooms[0]:(light_1,rollo_1),
    #all_rooms[1]:(light_2,rollo_2),
    #all_rooms[2]:(light_3,rollo_3),
    #all_rooms[3]:(light_4,rollo_4)
}

# -4- die für jeden URL der Website wird eine App angesteurt


'''
Apps werden wie folgt gestartet und ausgeführt:

@app.route("href") <-- für jeden Aufruf des hrefs in Klammern, wird die folgende Funktion aufgerufen. 
Funktion  <-- Diese Funktion wird ausgeführt, wenn auf 
return render_template("datei.html", Variable_in_Html_Datei=Variable_in_Python_Script, x=x, y="Hallo Welt", ... )
<-- die visuelle Darstellung wird von der datei.html übernommen. Diese nimmt die anderen Variablen in Empfang.
Diese werden mit Hilfe von Jinja(ein sogenannter "template engine") verarbeitet.

Hinweis zum @app.route:

Mit einem @ wird ein Decorator einer Funktion vorangestellt. Dieser verändert das Verhalten einer Funktion.
Was dieser Decorator in genau macht, ist für die Webentwicklung relativ unwichtig. 
Dieser wird von FLASK bereitgestellt und die exakte Funktionsweise muss den kleinen Mann und die kleine Frau nicht interessieren.
'''


#Start-Seite
@app.route("/")
def index():
    return render_template("start.html", title="Startseite", all_apps=all_apps) #html - template wird aufgerufen und mit Jinja-Logik formatiert

#Smarthome-Seite
@app.route("/smarthome")
def smarthome():	# der großteil der App wurde als Modul externalisiert und befindet sich im Ordner apps
    SmartHome.start(all_lights, all_rollos, light_configuration_list)
    return render_template("smarthome.html", title="Smarthome", all_rooms=all_rooms, zuordnung_dic=zuordnung_dic, all_apps=all_apps) #html - template wird aufgerufen und mit Jinja-Logik formatiert

#Info-Seite
@app.route("/info")
def info():
    return render_template("info.html", title="Info", all_apps=all_apps) #html - template wird aufgerufen und mit Jinja-Logik formatiert

