class Start():
	def start():
		
		return "hallo Welr"
