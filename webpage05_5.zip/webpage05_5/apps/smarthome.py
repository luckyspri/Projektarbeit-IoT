from flask import Flask, render_template, request
import time
import threading

class SmartHome(): #stellt Logik fuer Smart Home Webpage bereit
    def start (all_lights, all_rollos, light_configuration_list):
        argument_light = request.args.get("light") #liest Informationen aus href aus
        if argument_light != None: #Weiterleitung zur Lichtsteuerung
            SmartHome.light_control(argument_light, all_lights,light_configuration_list)
        argument_rollo = request.args.get("rollo")
        if argument_rollo != None: #Weiterleitung zur Rollladensteuerung
            SmartHome.rollo_control(argument_rollo, all_rollos)
        return None

    
    def light_control(argument, all_lights,light_configuration_list): #Steuert Lichter
    #das "argument" wurde aus dem href ausgelesen, welcher beim Klicken eines Buttons aufgerufen wird
        for element in all_lights: #Steuerung eines einzelnen Lichts
            if argument == element.name:
                element.change_status(light_configuration_list) #aendert Status und realisiert Steuerung
        if argument == "all_on": #stellt alle Lichter an
            for element in all_lights:
                element.status = "on" #aendert Status
                element.pi_steuerung(light_configuration_list) #realisiert Steuerung
        if argument == "all_off": #stellt alle Lichter aus
            for element in all_lights:
                element.status = "off" #aendert Status
                element.pi_steuerung(light_configuration_list) #realisiert Steuerung
 
        return all_lights

    def rollo_control(argument, all_rollos): #Steuert Rolllaeden
		#das "argument" wurde aus dem href ausgelesen, welcher beim Klicken eines Buttons aufgerufen wird
        for rollo in all_rollos: #Steuerung eines einzelnen Rollos
            if (argument == rollo.name):
                for thread in threading.enumerate(): 
                    if rollo.name == thread.name: #ueberprueft ob ein Thread existiert in dem der Rollladen faehrt
                        return None
                rollo.change_status() #aendert Status und realisiert Steuerung
                
        if argument == "all_down":
            activ_threads = threading.active_count()
            while activ_threads > 1: #verhinder das Ansteuern eines fahrenden Rollos, wartet bis alle Rollos stehen
                time.sleep(0.5)
                activ_threads = threading.active_count()
                continue
            for element in all_rollos:
                if element.status == "down":
                    continue
                elif element.status == "up":
                    element.change_status() #aendert Status und realisiert Steuerung
        
        if argument == "all_up":
            activ_threads = threading.active_count()
            while activ_threads > 1: #verhinder das Ansteuern eines fahrenden Rollos, wartet bis alle Rollos stehen
                time.sleep(0.5)
                activ_threads = threading.active_count()
                continue
            for element in all_rollos:
                if element.status == "up":
                    continue
                elif element.status == "down":
                    element.change_status()  #aendert Status und realisiert Steuerung

