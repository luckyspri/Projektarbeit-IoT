from flask import Flask, render_template, request

class Index():
    def index():
        items = ["ich", "du", "er", "dsi"]
        return render_template("start.html", name="Max Mustermann", items=items, title="Titel")
