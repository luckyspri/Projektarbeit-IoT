import smbus


bus = smbus.SMBus(1)
adresse = 0x20


class Light():
    def __init__ (self, name, nr):
        self.name = name
        self.status = "off"
        self.nr = nr
        
    def set(self, daten): #Function zum Senden der Information an das Bussystem
        write = bus.write_byte_data(adresse, 0x15, daten)
        return
    
    def change_status(self, pin_belegung_liste): #Aender Status
        if self.status == "on":
            self.status = "off"
        elif self.status == "off":
            self.status = "on"
        else:
            self.status = "off"
        self.pi_steuerung(pin_belegung_liste)    
        return self.status
        
    def pi_steuerung(self, pin_belegung_liste): #realisiert Statusaenderungen
        if self.status=="on":
            pin_belegung_liste[self.nr]=1
            x = self.bin_hex_convertion(pin_belegung_liste)
            self.set(x)
        if self.status=="off":
            pin_belegung_liste[self.nr]=0 #stellt licht aus
            x = self.bin_hex_convertion(pin_belegung_liste)
            self.set(x)
        return
    
    def bin_hex_convertion(self, pin_belegung_liste):
        #wandelt binaere Zahlenreihe in eine ganze Zahl fuer das Bussystem um
        pin_belegung_tuple = tuple(pin_belegung_liste)
        convertion_table = {(0,0,0,0):0,
                            (0,0,0,1):1,
                            (0,0,1,0):2,
                            (0,0,1,1):3,
                            (0,1,0,0):4,
                            (0,1,0,1):5,
                            (0,1,1,0):6,
                            (0,1,1,1):7,
                            (1,0,0,0):8,
                            (1,0,0,1):9,
                            (1,0,1,0):10,
                            (1,0,1,1):11,
                            (1,1,0,0):12,
                            (1,1,0,1):13,
                            (1,1,1,0):14,
                            (1,1,1,1):15,
                            }
        pin_belegung_int = convertion_table[pin_belegung_tuple]
        # ueber diese Art der Ansteuerung erwartet das Bussystem eine Dezimalzahl
        #Bei Ansteuerung ueber die Komandozeile wird eine Hexadezimalzahl erwartet
        return pin_belegung_int
        
        
        


