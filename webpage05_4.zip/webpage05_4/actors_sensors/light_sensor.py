import smbus


bus = smbus.SMBus(1)
adresse = 0x20


class LightSensor():
    def __init__ (self, name, pin_nr):
        self.name = name
        self.status = "off"
        self.pin_nr = pin_nr

    def get(self):
        read = bus.read_byte_data(0x20, 0x12)
        return read
    
    def state (self):
        state = self.get()
        own_state = self.hex_bin_convert(state)[self.pin_nr]
        comand = 0
        if own_state == 0: #gibt STOP Komando, wenn Dunkler Strich erreicht wird
            comand = "stop"        
        if own_state== 1: # gibt GO-Komando solang der Untergrund hell ist
            comand = "go"
        return comand

    def hex_bin_convert(self, state):
        convertion_table = {"0":(0,0,0,0),
                            "1":(0,0,0,1),
                            "2":(0,0,1,0),
                            "3":(0,0,1,1),
                            "4":(0,1,0,0),
                            "5":(0,1,0,1),
                            "6":(0,1,1,0),
                            "7":(0,1,1,1),
                            "8":(1,0,0,0),
                            "9":(1,0,0,1),
                            "a":(1,0,1,0),
                            "b":(1,0,1,1),
                            "c":(1,1,0,0),
                            "d":(1,1,0,1),
                            "e":(1,1,1,0),
                            "f":(1,1,1,1),
                            "x":(0,0,0,0)
                            #sind die ersten vier Stellen Null, so wird eine einstellige Hexadezimalzahl ausgegeben.
                            #die vorlestze Stelle ist dann ein x, durch die letzte Stelle im Dicitonary wird dieser Sondefall beruecksichtigt
                            }
        
        state_hex = hex(state)
        state_str = str(state_hex)
        state_one_str = state_str[-2:-1]
        state_two_str = state_str[-1:]
        positions_bin_one = convertion_table[state_one_str]
        positions_bin_two = convertion_table[state_two_str]
        positions_bin = positions_bin_one + positions_bin_two
        # ueber diese Art der Abfrage sendet das Bussystem eine Dezimalzahl
        #Bei Ansteuerung ueber die Komandozeile wird eine Hexadezimalzahl ausgegeben
        return positions_bin
