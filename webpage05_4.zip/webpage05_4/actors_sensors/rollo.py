from time import sleep
import RPi.GPIO as GPIO
import threading


GPIO.setmode(GPIO.BCM)
time=0.0015


class Rollo():
    def __init__ (self, name, gpio_A,gpio_B,gpio_C,gpio_D):
        self.name = name
        self.status = "up"
        #entscheidend fuer die Steuerung ueber die GPIO-Pins
        self.gpio_A = gpio_A
        self.gpio_B = gpio_B
        self.gpio_C = gpio_C
        self.gpio_D = gpio_D
        self.gpio_setupA = GPIO.setup(self.gpio_A,GPIO.OUT)
        self.gpio_setupB = GPIO.setup(self.gpio_B,GPIO.OUT)
        self.gpio_setupC = GPIO.setup(self.gpio_C,GPIO.OUT)
        self.gpio_setupD = GPIO.setup(self.gpio_D,GPIO.OUT)
        self.gpio_outputA = GPIO.output(self.gpio_A, False)
        self.gpio_outputB = GPIO.output(self.gpio_B, False)
        self.gpio_outputC = GPIO.output(self.gpio_C, False)
        self.gpio_outputD = GPIO.output(self.gpio_D, False) 

    def change_status(self): #ermoeglicht eine Statusaenderung
        if self.status == "down":
            self.status = "up"
        elif self.status == "up":
            self.status = "down"
        else:
            self.status = "up"
        self.pi_steuerung()
        return self.status
    
    def pi_steuerung(self): #uebernimmt die Steuerung der GPIOs, Fahrt innerhalb von Threads 
        if self.status == "up":
            t =threading.Thread(target=self.go_up, name=self.name)
        if self.status == "down":
            t =threading.Thread(target=self.go_down, name=self.name)
        t.start() 
    
    def go_to_startposition (self, sensor): #Regelt Fahrt bei Programmstart in Ausgangsposition
        while sensor.state() == "go":
            self.go_up_slow()
        if sensor.state() == "stop":
            return None

    
    def go_up (self): #Normale fahrt nach Unten
        for i in range (900):    
            self.Step8()
            self.Step7()
            self.Step6()
            self.Step5()
            self.Step4()
            self.Step3()
            self.Step2()
            self.Step1()
    
    def go_down(self):  #Normale Fahrt nach Oben
        for i in range (900):    
            self.Step1()
            self.Step2()
            self.Step3()
            self.Step4()
            self.Step5()
            self.Step6()
            self.Step7()
            self.Step8()  
                            
    def go_up_slow(self): #Fahrt nach oben in kleinen Schritten um rechtzeitig halten zu koennen
        for i in range (20):    
            self.Step8()
            self.Step7()
            self.Step6()
            self.Step5()
            self.Step4()
            self.Step3()
            self.Step2()
            self.Step1()  
    
    # Schritte 1 - 8 festlegen
    def Step1(self):
        GPIO.output(self.gpio_D, True)
        sleep (time)
        GPIO.output(self.gpio_D, False)

    def Step2(self):
        GPIO.output(self.gpio_D, True)
        GPIO.output(self.gpio_C, True)
        sleep (time)
        GPIO.output(self.gpio_D, False)
        GPIO.output(self.gpio_C, False)

    def Step3(self):
        GPIO.output(self.gpio_C, True)
        sleep (time)
        GPIO.output(self.gpio_C, False)

    def Step4(self):
        GPIO.output(self.gpio_B, True)
        GPIO.output(self.gpio_C, True)
        sleep (time)
        GPIO.output(self.gpio_B, False)
        GPIO.output(self.gpio_C, False)

    def Step5(self):
        GPIO.output(self.gpio_B, True)
        sleep (time)
        GPIO.output(self.gpio_B, False)

    def Step6(self):
        GPIO.output(self.gpio_A, True)
        GPIO.output(self.gpio_B, True)
        sleep (time)
        GPIO.output(self.gpio_A, False)
        GPIO.output(self.gpio_B, False)

    def Step7(self):
        GPIO.output(self.gpio_A, True)
        sleep (time)
        GPIO.output(self.gpio_A, False)

    def Step8(self):
        GPIO.output(self.gpio_D, True)
        GPIO.output(self.gpio_A, True)
        sleep (time)
        GPIO.output(self.gpio_D, False)
        GPIO.output(self.gpio_A, False)
    

